package wearpower.screenlocker;

import android.content.Context;

/**
 * Created by emir on 4/27/17.
 */

public class LogListener {


    public void logStringStringEntry(String s, String b){}
    public void logStringEntry(String s){}
    public void heartEntry(String s){}
    public void stepEntry(String s){}
    public void calorieEntry(String s){}
    public void deleteUploadedFiles(Context c) {}

}
