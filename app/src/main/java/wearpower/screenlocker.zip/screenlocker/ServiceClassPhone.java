
package wearpower.screenlocker;


import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.CpuUsageInfo;
import android.media.AudioManager;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import java.util.Vector;

import weka.classifiers.functions.LibSVM;
import weka.classifiers.trees.REPTree;
import weka.clusterers.SimpleKMeans;
import weka.core.Instances;


// * Created by emir on 5/7/17.
// *
// *
// * In this project, we are trying to lock/unlock screen with 3d movements of the phone
// *
// *


@TargetApi(Build.VERSION_CODES.CUPCAKE)
public class ServiceClassPhone extends Service implements SensorEventListener,
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {

    final private static boolean DBG = Definitions.DBG;
    final public static String TAG = "ServiceClassPhone";

    private static Logger mLogger = new Logger();

    private int mScreenBrightness = -1;
    private int sett =0;
    //  private UStats uStats;
    //  private Applications applications;
    private VoiceRecorder voiceRecorder;
    private TouchRecorder touchRecorder;


    private int cam_counter = 0;

    private boolean firstTime = true;
    private String fpsline;

    //  private TouchReading touch;

    private static long appStartTime = System.currentTimeMillis();
    private long unlock_notification = System.currentTimeMillis();

    private Instances data;
    private Instances dataUS;

    Button mButton;

    private LibSVM svm;
    private REPTree repTreeStatic;
    private REPTree repTreeUserSpecific;
    private SimpleKMeans kmeans;
    private DTW dtw;

    final private static Object mLogLock = new Object();

    private boolean screenIsOn = true;
    private boolean camOn = false;

    private int sendToServerNeeded = 0;

    private int user_input = 0;
    private int count = 0;


    public static final String INTENT_EXTRA_OUTCOME = "outcome";
    public static final String INTENT_EXTRA_TIMESTAMP = "timestamp";
    public static final String INTENT_EXTRA_NOTE = "note";
    public static final String INTENT_EXTRA_VERSION = "version";

    final private static Object mFileUploadLock = new Object();
    public static final String SHARED_PREFS_NAME = ServiceClassPhone.class.getPackage().getName();
    private static final String LASTUPLOAD_SP_KEY = "LastUpload";
    private static final String DISSATISFACTION_ARRAY = "DissatisfactionArray";
    private static final String USERMODELTRAINING = "UserModelTraining";


    //   private static final byte[] FPS_DATA = FileRepeatReader.generateReadfileCommand(FPS_PATH);
    private static Vector<Double> fpsLogs = new Vector<Double>();

    private static long cpu_conf_time_interval = 100; // 30 sec to change cpu configuration

    private int counter_for_arff = 0;

    private int order = 0;
    private double power = 0.0;
    private int counter_for_power = 0;
    private int counter_for_day = 0;
    private double current_now = 0;
    private double voltage = 0;
    private double current_avg = 0;
    private double voltage_avg = 0;
    private double voltage_sum = 0;
    private double current_sum = 0;
    private double power_sum = 0;
    private double power_avg = 0;

    private double avg_voice = 0;
    private double min_voice = 0;
    private double max_voice = 0;

    private int batt_level = 50;

    public int SETTING = -1;


    private String morning_night_now = "noon";
    private double time_hour_now= -1;

    IntentFilter filter;
    IntentFilter powerfilter;

    private boolean screen_clicked = false;

    private long lastModelStartTime = 0;

    private long lastTimeCpu = System.currentTimeMillis();

    ArrayList<Double> accell_p_x;
    ArrayList<Double> accell_p_y;
    ArrayList<Double> accell_p_z;
    ArrayList<Double> accell_p_x_set;
    ArrayList<Double> accell_p_y_set ;
    ArrayList<Double> accell_p_z_set;
    ArrayList<Double> accell_p_x_test;
    ArrayList<Double> accell_p_y_test ;
    ArrayList<Double> accell_p_z_test;

    // creating arrayLists of ArrayLists
    ArrayList<Double>[] accell_p_x_t;
    ArrayList<Double>[] accell_p_y_t;
    ArrayList<Double>[] accell_p_z_t;
    ArrayList<Double>[] gyro_p_x_t;
    ArrayList<Double>[] gyro_p_y_t;
    ArrayList<Double>[] gyro_p_z_t;
    ArrayList<Double>[] ambient_t;
    ArrayList<Double>[] pressure_t;
    ArrayList<Double>[] touch_binary_t;
    ArrayList<Double>[] power_t;
    ArrayList<Double>[] current_t;
    ArrayList<Double>[] voltage_t;
    ArrayList<Double>[] avg_voice_t ;
    ArrayList<Double>[] min_voice_t;
    ArrayList<Double>[] max_voice_t;
    ArrayList<Double>[] time_hour_t;
    ArrayList<Double>[] batt_level_t;
    ArrayList<Double>[] scrBrigtness_t;


    private SensorManager mSensorManager; // sensor manager and sensor event listener objects

    private boolean isPhoneLocked = false;

    private PowerManager powerManager;                  // wake lock to make this app runs even in screen off
    public PowerManager.WakeLock wakeLock;

    //private AlertDialog dialog=null;

    private String accellerometerSensor = "";
    private String heartRateSensor = "";
    private String stepCounterSensor = "";
    private String gyroscopeSensor = "";
    private int accellerometerEvent = 0;
    private int heartRateEvent = 0;
    private int stepCounterEvent = 0;
    private String touchEvents = "";
    private int gyroscopeEvent = 0;
    private int proximityEvent = 0;
    private String proximitySensor = "";
    private int pressureEvent = 0;
    private String pressureSensor = "";
    private boolean pressure_available = false;
    private int ambientEvent = 0;
    private String ambientSensor = "";
    private double accell_phone_x = 0;
    private double accell_phone_y = 0;
    private double accell_phone_z = 0;
    private double gyro_phone_x = 0;
    private double gyro_phone_y = 0;
    private double gyro_phone_z = 0;
    private double pressure = 0;
    private double ambient = 0;
    private double DISTANCE_X = 50;
    private double DISTANCE_Y = 50;
    private double DISTANCE_Z = 80;

    private int input_counter = 1800;
    private long lastTimeActivity = 0;

    private long lastUploadTime = System.currentTimeMillis();

    private long screen_brightness_changed_time = System.currentTimeMillis();

    private boolean sets_collected = false;
    private boolean locked = false;
    private long lastToastTime = 0;

    private long lastTime = System.currentTimeMillis();
    private long lastFileSize = System.currentTimeMillis();

    /*
    Screen Study --> Features with no pressure sensor
    Attributes:   17
    accel_p_x
    accel_p_y
    accel_p_z
    gyro_p_x
    gyro_p_y
    gyro_p_z
    ambient
    pressure
    touch_filter
    power
    current
    voltage
    avg_voice
    min_voice
    max_voice
    time_hour
    day_night
    y  =  screen_bright

    */

    // TODO: features names should be same with the models created!
    private static String[]  featureList = {"accel_p_x", "accel_p_y", "accel_p_z",
            "gyro_p_x", "gyro_p_y", "gyro_p_z", "ambient", "pressure",
            "touch_filter", "avg_voice", "min_voice", "max_voice",
            "time_hour" , "day_night" , "batt_lev" ,  "screen_bright"};

    // "power" , "current" , "voltage",


    public static int STATE;

    public static final int INACTIVE=0;
    public static final int ACTIVE=1;

    static{
        STATE=INACTIVE;
    }


    public ActivityManager mActivityManager;

    private final IBinder mBinder = new LocalBinder();


    /*
    GoogleApiClient mGoogleApiClient = new GoogleApiClient.Builder(ServiceClassPhone.this)
            .addConnectionCallbacks(ServiceClassPhone.this)
            .addOnConnectionFailedListener(ServiceClassPhone.this)
            .addApi(ActivityRecognition.API)
            .build();
    */
    GoogleApiClient mGoogleApiClient = null;


    @Override
    public void onCreate() {

        try {

            try {
                createInitiateLogFiles();
            }catch (Exception e){
                if(DBG)Log.d(TAG , "Error in file creation in onCreate");
            }

            try {
                initiateArrayLists();
            }catch (Exception e){
                if(DBG)Log.d(TAG , "Error in initiating linked lists in onCreate");
            }


            if (DBG) Log.d(TAG, "Touch/Voice are formed: ");

            mActivityManager = (ActivityManager) this.getSystemService(ACTIVITY_SERVICE);

            if (DBG) Log.d(TAG, "Touch/Voice are formed2: ");

            // get device manufacturer name
            mLogger.logStringEntry("P_Dev: " + getDeviceName());

            if (DBG) Log.d(TAG, "Registers are formed: ");

            //  voiceRecorder = new VoiceRecorder();
            // touchRecorder = new TouchRecorder();

            mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

            registerAll();
            startSensorListeners();
            mCollectorHandler.postDelayed(mCollectorRefresh, 2000);
            //  mTouchHandler.postDelayed(mTouchRefresh, 2000);
             powerHandler.postDelayed(powerRefresh, 2000);
            sensorHandler.postDelayed(sensorRefresh, 2000);
            //cpuHandler.postDelayed(cpuRefresh, 2000);


            if(DataHolder.getInstance().getVoicePermission()){
                //voiceRecorder.start();
                //  touchRecorder.start();
            }

            if(DBG) Log.d(TAG, "service class after voice recorder ");
            STATE = ACTIVE;

        } catch (Exception e) {
            if(DBG)Log.d(TAG, "Error Occured in ServiceClass1: " + e.toString() + " " + e.getStackTrace());
            if (DBG) {
                if(DBG) Log.e(TAG, "Brightness setting not found " + e);
            }
            STATE = INACTIVE;
        } catch (Throwable t) {
            if(DBG)Log.d(TAG, "Error Occured in ServiceClass2: " + t.toString() + " " + t.getStackTrace());
            STATE = INACTIVE;
        }
    }

    public void createInitiateLogFiles(){
        try {

            // create and initiate files if they are already not there
            mLogger.createLogFile(this);
            // Logger.createLogFileToUpload(this);
            mLogger.logStringEntry("Logger On");

            mLogger.createArffFile(this);  // for weka ml, arff file format to use in instant predictions

            Logger.createArffFileUsModel(this);

            File arff_file = new File(Definitions.ARFF_FILE_NAME);

            if (DBG) Log.d(TAG, "Arff File length is: " + arff_file.length());

            if (arff_file.length() <= 20) {

                Logger.InitiateArffFile(featureList);
            }

            // if there is a problem and app crashes bc of data in it
            SharedPreferences prefs = getSharedPreferences(Definitions.APP_STARTED, Context.MODE_PRIVATE);
            long lastTimeAppStarted = prefs.getLong(Definitions.APP_STARTING_TIME, 0);
            if (System.currentTimeMillis() - lastTimeAppStarted <= Definitions.THREE_MIN) {
                mLogger.deleteUploadedFiles(this);
                mLogger.createLogFile(this);
                mLogger.logStringEntry("Logger On");
                //System.out.println("here!");
            }
            prefs.edit().putLong(Definitions.APP_STARTING_TIME, System.currentTimeMillis()).commit();
            Log.d(TAG, String.valueOf(this.getFilesDir()));
            if (DBG) Log.d(TAG, "Shared pref app start time is written");




        }catch (Exception e){
            Log.d(TAG , "Error in creating files: " + e);
        }
    }


    private void initiateArrayLists(){
        accell_p_x_set = new ArrayList<>();
        accell_p_y_set = new ArrayList<>();
        accell_p_z_set = new ArrayList<>();

        accell_p_x_test = new ArrayList<>();
        accell_p_y_test = new ArrayList<>();
        accell_p_z_test = new ArrayList<>();

        // creating arrayLists of ArrayLists



    }



    public void registerAll() {
        // screen on/off + wifi manager rssi + airplane mode + date + timezone + headset plugged +
        // applications = all of them (music, browser, game?, texting, radio)
        // how much each app is used, optimal configuration...
        // current app info and current cpu conf? also

        IntentFilter filter = new IntentFilter();
        //powerfilter = new IntentFilter();

        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SCREEN_ON);
        /*
        filter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        filter.addAction(Intent.ACTION_CAMERA_BUTTON);
        filter.addAction(Intent.ACTION_CONFIGURATION_CHANGED);
        filter.addAction(Intent.ACTION_DATE_CHANGED);
        filter.addAction(Intent.ACTION_DEVICE_STORAGE_LOW);
        filter.addAction(Intent.ACTION_DEVICE_STORAGE_OK);
        filter.addAction(Intent.ACTION_HEADSET_PLUG);
        filter.addAction(Intent.ACTION_MANAGE_PACKAGE_STORAGE);
        // PUT INTO PHONE STUFF? - skipping for now

        filter.addAction(Intent.ACTION_TIME_CHANGED);
        filter.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        filter.addAction(Intent.ACTION_UMS_CONNECTED);
        filter.addAction(Intent.ACTION_UMS_DISCONNECTED);

        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        //powerfilter.addAction(Intent.ACTION_BATTERY_CHANGED);

        filter.addAction(AudioManager.VIBRATE_SETTING_CHANGED_ACTION);
        filter.addAction(String.valueOf(BatteryManager.BATTERY_STATUS_CHARGING));
        filter.addAction(String.valueOf(BatteryManager.BATTERY_STATUS_FULL));
        filter.addAction(String.valueOf(BatteryManager.BATTERY_PLUGGED_USB));
        filter.addAction(String.valueOf(BatteryManager.BATTERY_PLUGGED_AC));
        filter.addAction(String.valueOf(BatteryManager.BATTERY_STATUS_NOT_CHARGING));

        registerReceiver(mBroadcastIntentReceiver, filter);
       // registerReceiver(powerBroadcastreceiver, powerfilter);

      */
        filter.addAction(String.valueOf(BatteryManager.BATTERY_STATUS_CHARGING));
        filter.addAction(String.valueOf(BatteryManager.BATTERY_STATUS_FULL));
        filter.addAction(String.valueOf(BatteryManager.BATTERY_PLUGGED_USB));
        filter.addAction(String.valueOf(BatteryManager.BATTERY_PLUGGED_AC));
        filter.addAction(String.valueOf(BatteryManager.BATTERY_STATUS_NOT_CHARGING));
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        registerReceiver(mBroadcastIntentReceiver, filter);
    }

    public String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        int ver = Build.VERSION.SDK_INT;
        if (model.toLowerCase().startsWith(manufacturer.toLowerCase())) {
            return capitalize(model)+"-"+ver;
        } else {
            return capitalize(manufacturer) + "-" + model +"-"+ver;
        }
    }


    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "None";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }


    public static Logger getLogger() {
        return mLogger;
    }


    BroadcastReceiver mBroadcastIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {


            if (intent.getAction().equals(Intent.ACTION_BATTERY_CHANGED)) {

                int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                boolean isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL;

                //    How are we charging?
                //   int chargePlug = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
                //    boolean usbCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_USB;
                //    boolean acCharge = chargePlug == BatteryManager.BATTERY_PLUGGED_AC;

                if (isCharging) {
                    mLogger.logStringEntry("Usb_charging: " + isCharging);
                }
                //  Log.d(TAG,"Battery status usb and ac: " + usbCharge + " "+acCharge);
                if (DBG) Log.d(TAG, "Battery status is charging: " + isCharging);

                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught USB_CHARGING <<<<<<<<<<<");
                }
                //  mLogger.logEntry("USB_CHARGING");
                int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0);
                mLogger.logStringEntry("Batt: " + level);
                batt_level = level;

            } else if (intent.getAction().equals(Intent.ACTION_POWER_CONNECTED)) {
                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught ACTION_POWER_CONNECTED <<<<<<<<<<<");
                }
                mLogger.logStringEntry("Power_Connected");
            } else if (intent.getAction().equals(Intent.ACTION_POWER_DISCONNECTED)) {
                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught ACTION_POWER_DISCONNECTED <<<<<<<<<<<");
                }
                mLogger.logStringEntry("Power_DisConnected");
            } else if (intent.getAction().equals(String.valueOf(BatteryManager.BATTERY_PLUGGED_USB))) {
                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught BATTERY_PLUGGED_USB <<<<<<<<<<<");
                }
                mLogger.logStringEntry("BATTERY_PLUGGED_USB");
            } else if (intent.getAction().equals(String.valueOf(BatteryManager.BATTERY_STATUS_CHARGING))) {
                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught BATTERY_STATUS_CHARGING <<<<<<<<<<<");
                }
                mLogger.logStringEntry("BATTERY_STATUS_CHARGING");
            } else if (intent.getAction().equals(String.valueOf(BatteryManager.BATTERY_STATUS_NOT_CHARGING))) {
                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught BATTERY_STATUS_NOT_CHARGING <<<<<<<<<<<");
                }
                mLogger.logStringEntry("BATTERY_STATUS_NOT_CHARGING");
            } else if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught ACTION_SCREEN_OFF <<<<<<<<<<<");
                }
                //mLogger.logSimpleEntry(Logger.EntryType.SCREEN_OFF);
                mLogger.logStringEntry("ScreenOff");
                screenIsOn = false;
                //  if(wakeLock==null)wakeLock.acquire();

            } else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught ACTION_SCREEN_ON <<<<<<<<<<<");
                }
                //mLogger.logSimpleEntry(Logger.EntryType.SCREEN_ON);
                if (screenIsOn == false) {
                    //  moodModule.getCurrentMood();
                }
                mLogger.logStringEntry("ScreenOn");
                screenIsOn = true;

                //   if (wakeLock!=null ||  wakeLockisOn) wakeLock.release();
                //    wakeLock=null;

            } else if (intent.getAction().equals(Intent.ACTION_BATTERY_CHANGED)) {
                if (DBG) {
                    Log.i(TAG, ">>>>>>>>>> caught ACTION_BATTERY_CHANGED <<<<<<<<<<<");
                }

            } else if (intent.getAction().equals(WifiManager.RSSI_CHANGED_ACTION)) {
                Bundle extra = intent.getExtras();
                int strength = extra.getInt(WifiManager.EXTRA_NEW_RSSI);

                if (DBG) {
                    Log.i(TAG, "Wifi signal strength: " + strength);
                }
                //mLogger.logIntEntry(Logger.EntryType.WIFI_SIGNAL_STRENGTH, strength);
                mLogger.logStringEntry("Wifi signal strength: " + strength);
            } else if (intent.getAction().equals(Intent.ACTION_AIRPLANE_MODE_CHANGED)) {
                Bundle extra = intent.getExtras();
                if (true == (Boolean) extra.get("state")) {
                    if (DBG) {
                        Log.i(TAG, ">>>>>>>>>> AIRPLANE MODE: on <<<<<<<<<<<");
                    }
                    //mLogger.logSimpleEntry(Logger.EntryType.AIRPLANE_MODE_ON);
                    mLogger.logStringEntry("Airplane_On");
                } else {
                    if (DBG) {
                        Log.i(TAG, ">>>>>>>>>> AIRPLANE MODE: off <<<<<<<<<<<");
                    }
                    //mLogger.logSimpleEntry(Logger.EntryType.AIRPLANE_MODE_OFF);
                    mLogger.logStringEntry("Airplane_Off");
                }
            } else if (intent.getAction().equals(Intent.ACTION_DATE_CHANGED)) {
                if (DBG) {
                    Log.i(TAG, "Date changed");
                }
                //mLogger.logSimpleEntry(Logger.EntryType.DATE_CHANGED);
                mLogger.logStringEntry("Date_changed");
            } else if (intent.getAction().equals(Intent.ACTION_HEADSET_PLUG)) {
                Bundle extra = intent.getExtras();
                String state = "";
                switch ((Integer) extra.get("state")) {
                    case 0:
                        state = "unplugged";
                        break;
                    case 1:
                        state = "plugged";
                        break;
                    default:
                        state = "invalid";
                        break;
                }
                if (DBG) {
                    Log.i(TAG, "Headset Plug: " + state);
                }
                //mLogger.logStringEntry(Logger.EntryType.HEADSET_PLUG, state);
                mLogger.logStringEntry("Headset_Plug: " + state);
            } else if (intent.getAction().equals(Intent.ACTION_TIME_CHANGED)) {
                if (DBG) {
                    Log.i(TAG, "Time changed");
                }
                //mLogger.logSimpleEntry(Logger.EntryType.TIME_CHANGED);
                mLogger.logStringEntry("Time_Changed");
            } else if (intent.getAction().equals(Intent.ACTION_TIMEZONE_CHANGED)) {
                Bundle extra = intent.getExtras();
                String timezone = (String) extra.get("time-zone");
                TimeZone tz = TimeZone.getTimeZone(timezone);
                int tz_offset = tz.getRawOffset();
                if (DBG) {
                    Log.i(TAG, "Timezone Change: " + tz_offset);
                }
                //mLogger.logIntEntry(Logger.EntryType.TIMEZONE_CHANGED, tz_offset);
                mLogger.logStringEntry("Timezone_Changed: " + tz_offset);


                // TODO: POSSIBLY STOP LOGGING WHEN STORAGE IS LOW
            } else if (intent.getAction().equals(Intent.ACTION_DEVICE_STORAGE_LOW)) {
                if (DBG) {
                    Log.i(TAG, "Device Storage Low");
                }
                //mLogger.logSimpleEntry(Logger.EntryType.DEVICE_STORAGE_LOW);
                mLogger.logStringEntry("Device_Storage_Low");
            } else if (intent.getAction().equals(Intent.ACTION_DEVICE_STORAGE_OK)) {
                if (DBG) {
                    Log.i(TAG, "Device Storage Ok");
                }
                //mLogger.logSimpleEntry(Logger.EntryType.DEVICE_STORAGE_OK);
                mLogger.logStringEntry("Device_Storage_Ok");
            }

            // low memory condition acknowledged by user - start package management
            else if (intent.getAction().equals(Intent.ACTION_MANAGE_PACKAGE_STORAGE)) {
                if (DBG) {
                    Log.i(TAG, "Manage Package Storage");
                }
                //mLogger.logSimpleEntry(Logger.EntryType.MANAGE_PACKAGE_STORAGE);
                mLogger.logStringEntry("Manage_Package_Storage");
            } else if (intent.getAction().equals(Intent.ACTION_UMS_CONNECTED)) {
                if (DBG) {
                    Log.i(TAG, "UMS Connected");
                }
                mLogger.logStringEntry("UMS_Connected");
            } else if (intent.getAction().equals(Intent.ACTION_UMS_DISCONNECTED)) {
                if (DBG) {
                    Log.i(TAG, "UMS Connected");
                }
                mLogger.logStringEntry("UMS_Disconnected");
            }

            // TODO ensure this vibrate settings thing works
            else if (intent.getAction().equals(AudioManager.VIBRATE_SETTING_CHANGED_ACTION)) {
                if (DBG) {
                    Log.i(TAG, "Vibrate Setting changed");
                }

            }
        }
    };

    @Override
    public void onDestroy() {
        try {
            Toast.makeText(this, "App is closing", Toast.LENGTH_LONG).show();
            try{
                unregisterReceiver(mBroadcastIntentReceiver);
            }catch (Exception e){
                Log.d(TAG, "ERROR while destroy: " + e);
            }
            try{
                mCollectorHandler.removeCallbacksAndMessages(null);
            }catch (Exception e){
                Log.d(TAG, "ERROR while destroy: " + e);
            }

            try{
                sensorHandler.removeCallbacksAndMessages(null);
            }catch (Exception e){
                Log.d(TAG, "ERROR while destroy: " + e);
            }
            try{
                unregisterReceiver(powerBroadcastreceiver);
                powerHandler.removeCallbacksAndMessages(null);
            }catch (Exception e){
                Log.d(TAG, "ERROR while destroy: " + e);
            }
            try{
                //
                // voiceRecorder.stop();
                stopSensorListeners();
            }catch (Exception e){
                Log.d(TAG, "ERROR while destroy: " + e);
            }

            //Intent service = new Intent(this, ServiceClassPhone.class);
            Intent service = new Intent(this, ScreenService.class);
            Intent intent = new Intent(ServiceClassPhone.this, DetectedActivitiesIntentService.class);
            ServiceClassPhone.this.stopService(intent);
            //   MyWakefulReceiver.completeWakefulIntent(service);

            STATE = INACTIVE;
            stopSelf();
        } catch (Exception e) {
            if (DBG) Log.d(TAG, "ERROR on destroy: " + e);
        }
    }

    public boolean writeDataToArrayList1(int set_for){
        try {
            accell_p_x_t[set_for].add(accell_phone_x);
            accell_p_y_t[set_for].add(accell_phone_y);
            accell_p_z_t[set_for].add(accell_phone_z);
            gyro_p_x_t[set_for].add(gyro_phone_x);
            gyro_p_y_t[set_for].add(gyro_phone_y);
            gyro_p_z_t[set_for].add(gyro_phone_z);
            ambient_t[set_for].add(ambient);
            pressure_t[set_for].add(pressure);
            touch_binary_t[set_for].add((double) DataHolder.getInstance().getUserInput());
            power_t[set_for].add(power_avg);
            current_t[set_for].add(current_avg);
            voltage_t[set_for].add(voltage_avg);
            avg_voice_t[set_for].add(avg_voice);
            min_voice_t[set_for].add(min_voice);
            max_voice_t[set_for].add(max_voice);
            time_hour_t[set_for].add(time_hour_now);
            batt_level_t[set_for].add((double) batt_level);
            scrBrigtness_t[set_for].add((double) mScreenBrightness);
            return true;
        }catch (Exception e){
            if(DBG) Log.d(TAG , "ERROR in setting to arraylist: " + set_for);
        }
        return false;
    }

    public boolean writeDataToArrayList(){
        try {
            accell_p_x_set.add(accell_phone_x);
            accell_p_y_set.add(accell_phone_y);
            accell_p_z_set.add(accell_phone_z);
            return true;
        }catch (Exception e){
            if(DBG) Log.d(TAG , "ERROR in setting to arraylist: ");
        }
        return false;
    }

    public double[] formArraysFromArrayLists(ArrayList<Double> arrayList){
        double[] target = new double[arrayList.size()];
        for (int i = 0; i < target.length; i++) {
            target[i] = arrayList.get(i).doubleValue();  // java 1.4 style
            // or:
            target[i] = arrayList.get(i);                // java 1.5+ style (outboxing)
        }
        return target;
    }

    private double[][] getDoubleArray(ArrayList<Double> arrayList , ArrayList<Double> arrayList_t){
        //int min_size = Math.min(arrayList.size() , arrayList_t.size());

        int min_size = arrayList_t.size();

        if (DBG) Log.d(TAG , "min size is: " + min_size + " " + arrayList.size() + " " + arrayList_t.size());

        double[][] lists = new double[][] {new double[min_size] , new double[min_size]};

        for (int i = arrayList.size() - min_size; i < arrayList.size(); i++) {
            lists[0][i-(arrayList.size() - min_size)] = arrayList.get(i);                // java 1.5+ style (outboxing)
        }
        for (int j = arrayList_t.size() - min_size; j < arrayList_t.size(); j++) {
            lists[1][j] = arrayList_t.get(j);                // java 1.5+ style (outboxing)
        }
        return lists;
    }

    public boolean writeDataToArrayListTest(){
        accell_p_x_test.add(accell_phone_x);
        accell_p_y_test.add(accell_phone_y);
        accell_p_z_test.add(accell_phone_z);

        if (accell_p_x_test.size() > accell_p_x_set.size()) {
            accell_p_x_test.remove(0);
            accell_p_y_test.remove(0);
            accell_p_z_test.remove(0);

            if(DBG) Log.d(TAG, "DISTANCES test: " + accell_p_x_test.get(accell_p_x_test.size()-1) + " "
                    + accell_p_x_test.get(accell_p_x_test.size()-2) + " "
                    + accell_p_x_test.get(accell_p_x_test.size()-3) + " ");

            if(DBG) Log.d(TAG, "DISTANCES set: " + accell_p_x_set.get(accell_p_x_set.size()-1) + " "
                    + accell_p_x_set.get(accell_p_x_set.size()-2) + " "
                    + accell_p_x_set.get(accell_p_x_set.size()-3) + " ");

        }
        return true;
    }



    public boolean keepTrackAndCheck(){
        try {

            if(accell_p_x_test.size() < accell_p_x_set.size()){
                return false;
            }

            double d1 = dtw.dd(accell_p_x_set, accell_p_x_test, 10);
            double d2 = dtw.dd(accell_p_y_set, accell_p_y_test, 10);
            double d3 = dtw.dd(accell_p_z_set, accell_p_z_test, 10);
            if(DBG) Log.d(TAG, "DISTANCES: " + d1 + " " + d2 + " " + d3);
            return d1 < DISTANCE_X && d2 < DISTANCE_Y && d3 < DISTANCE_Z;

        }catch (Exception e){
            if(DBG) Log.d(TAG , "ERROR in keeping track and checking: " + e);
        }
        return false;
    }



    Handler mCollectorHandler = new Handler();   // handler is more convenient for massage passing between objects and also UI friendly.
    // so if we need to put some info or even in notifications we may need handler instead of thread.
    Runnable mCollectorRefresh = new Runnable() {


        @Override
        public void run() {


            try {
                //ScreenService.ACCESSIBILITY_SERVICE;

                try{
                    determineTimeDay();
                }catch (Exception e){
                    Log.d(TAG , "Error in time/day");
                }

                if (DataHolder.getInstance().getVoiceStarted()==false){
                    // voiceRecorder.start();
                }

                // if input is received reset input counter
                if (screen_clicked) input_counter=0;

                // check if screen is locked so set screen brightness to 0

                KeyguardManager myKM = (KeyguardManager) getApplicationContext().getSystemService(Context.KEYGUARD_SERVICE);
                isPhoneLocked = myKM.isKeyguardLocked();
                if (isPhoneLocked){
                    mScreenBrightness = 0;
                    input_counter = 1800;
                }
                else{
                    mScreenBrightness = Settings.System.getInt(getContentResolver(),
                            Settings.System.SCREEN_BRIGHTNESS);
                }

                /*
                make sure screen brightness is not in adaptive! or it can be adaptive if its user's choice
                 */


                if (screenIsOn==false) mScreenBrightness = 0;


                power_avg = power_sum / counter_for_power;
                current_avg = current_sum /counter_for_power;
                voltage_avg = voltage_sum /counter_for_power;

                avg_voice = DataHolder.getInstance().getAvgVoice();
                min_voice = DataHolder.getInstance().getMinVoice();
                max_voice = DataHolder.getInstance().getMaxVoice();


                mLogger.logStringEntry("PowCV: " + power_avg  + " " + current_avg + " " + voltage_avg );

                // check model and if its been one day change it

                // write to temp file to make predictions based on updated data


                if (System.currentTimeMillis() - DataHolder.getInstance().getUserInputTime() >2000){ // 2 sec since usr in continue with manual
                    DataHolder.getInstance().setUserInput(0);
                }


                power_sum = 0.0;
                current_sum = 0.0;
                voltage_sum = 0.0;
                counter_for_power = 0;

                //VoiceRecorder.getInstance().setAvgVoice(1,0);
                //VoiceRecorder.getInstance().setMinVoice(0.0);
                //VoiceRecorder.getInstance().setMaxVoice(0.0);
                if(DBG) Log.d(TAG, "Collector Handler");

                mCollectorHandler.postDelayed(mCollectorRefresh, 1000); // in every 3 sec

            } catch (Exception e) {
                if(DBG) Log.i(TAG, "Error occured in collector: " + e);
                mCollectorHandler.postDelayed(mCollectorRefresh, 200000);
            }
        }
    };



    private void determineTimeDay(){
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-HH-mm-ss");
        String current_time = dateFormat.format(date);
        String[] parts = current_time.split("-");
        time_hour_now = Double.parseDouble(parts[2]);
        if(DBG) Log.d(TAG , "time hour: " + time_hour_now);
        if (time_hour_now>=6 && time_hour_now<10) morning_night_now = "morning";
        else if (time_hour_now>=10 && time_hour_now<16) morning_night_now = "noon";
        else if (time_hour_now>=16 && time_hour_now<20) morning_night_now = "evening";
        else  morning_night_now = "night";
    }


    Handler sensorHandler = new Handler();
    Runnable sensorRefresh = new Runnable() {

        @Override
        public void run() {

            try {

              //  mLogger.logStringEntry("Accel: " + accellerometerSensor);
              //  Log.d(TAG, "Accel: " + accellerometerSensor);
              //  mLogger.logStringEntry("Gyro: " + gyroscopeSensor);
              //  Log.d(TAG, "Gyro: " + gyroscopeSensor);
              //  mLogger.logStringEntry("Time_of_Day: " + morning_night_now);
              //  Log.d(TAG, "Time_of_Day: " + morning_night_now);

                if (mScreenBrightness >= 170) {
                    setBrightness(50);
                }
                else if (mScreenBrightness <= 70) {
                    setBrightness(200);
                }
                //mLogger.logStringEntry("PowCV: " + power_avg  + " " + current_avg + " " + voltage_avg );
                mScreenBrightness = Settings.System.getInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS);
                mLogger.logStringEntry("Brightness: " + mScreenBrightness);
                Log.d(TAG, "Brightness: " + mScreenBrightness);
                SETTING = DataHolder.getInstance().getSetCount();
                if(DBG) Log.d(TAG, "SETTING: " + SETTING);
                count += 1;
                if (SETTING == 0){
                    initiateArrayLists();
                    DataHolder.getInstance().setSetCount(1);
                    SETTING += 1;
                }
                if(SETTING == 1){
                    writeDataToArrayList();
                }
                if (SETTING == 2){
                    writeDataToArrayListTest();
                    if (keepTrackAndCheck()){
                        if(DBG) Log.d(TAG, "\n\n\n<<<<<<<Unlocked!>>>>\n\n\n");
                        if (System.currentTimeMillis() - unlock_notification >= 4000) {
                            UNCLOCKED();
                            unlock_notification = System.currentTimeMillis();
                        }
                    }
                    count = 0;

                }
                //collectSensors();

                sensorHandler.postDelayed(sensorRefresh, 90); // 20 Hertz

            } catch (Exception e) {
                if(DBG) Log.i(TAG, "Error occured in linked list writing probably" + e);
                sensorHandler.postDelayed(sensorRefresh, 90); // 20 Hertz
            }
        }
    };

    Handler cpuHandler = new Handler();
    Runnable cpuRefresh = new Runnable() {

        @Override
        public void run() {

            try {
                double power_now = -1.0;

                try {
                    //CPUUSAGEINFO IS PRIVATE???
                    //CpuUsageInfo cpu_usage = new CpuUsageInfo(0.0,0.0);

                } catch (Exception e) {
                    Log.d(TAG, "Voltage Error: " + e);
                }


                powerHandler.postDelayed(powerRefresh, cpu_conf_time_interval * 5); // in every 0.5 sec

            } catch (Exception e) {
                Log.i(TAG, "Error occured " + e);
                powerHandler.postDelayed(powerRefresh, cpu_conf_time_interval * 5); // in every 0.5 sec
            }
        }
    };

    private void UNCLOCKED(){
        Toast.makeText(this, "Unlocked", Toast.LENGTH_SHORT).show();
    }


    BroadcastReceiver powerBroadcastreceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            BatteryManager mBatteryManager = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
            voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE,0);

            current_now = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);

            if(DBG) Log.d(TAG , "Power current and voltage: " + current_now + " " + voltage);

        }
    };

    private void setBrightness(double brightness) {
        boolean set = false;
        if (mScreenBrightness - 8 >= brightness) {
            brightness = mScreenBrightness - 3;
            set = true;
        }
        //if (ambient/5>brightness) brightness+=5;
        else if (mScreenBrightness < brightness - 15) {
            brightness = mScreenBrightness + 2;
            set = true;
        } else {
            brightness = mScreenBrightness;
        }
        if (set) {
            try {
                int auto = Settings.System.getInt(getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS_MODE);
                if (auto == 1) {
                    Settings.System.putInt(getContentResolver(),
                            Settings.System.SCREEN_BRIGHTNESS_MODE,
                            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                }
                Settings.System.putInt(getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS, (int) brightness);

                if(DBG) Log.d(TAG, "setBrightness Brightness should be set: " + brightness + " " +
                        Settings.System.getInt(getContentResolver(),
                                Settings.System.SCREEN_BRIGHTNESS));

                mScreenBrightness = Settings.System.getInt(getContentResolver(),
                        Settings.System.SCREEN_BRIGHTNESS);
            } catch (Exception e) {
                Log.e(TAG, "Error on reading brightness settings: " + e.toString());
            }
        }
        if(DBG) Log.d(TAG, "setBrightness: " + brightness);
    }



    Handler powerHandler = new Handler();   // handler is more convenient for massage passing between objects and also UI friendly.
    // so if we need to put some info or even in notifications we may need handler instead of thread.
    Runnable powerRefresh = new Runnable() {


        @Override
        public void run() {

            try {
                double power_now = -1.0;

                try {
                    IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                    registerReceiver(powerBroadcastreceiver, filter);
                    ServiceClassPhone.this.registerReceiver(powerBroadcastreceiver,filter);

                    // if (DBG)
                    //   Log.d(TAG, "Power current and voltage : " + current_now + " " + voltage);

                    // voltage = voltageNow.readVoltage();
                    //current_now = voltageNow.readCurrent();

                    current_now = current_now/1000; // from micro ampher to milli ampher voltage is alread milivolt

                    power_now = current_now * voltage / 1000; // mW

                    power_sum = power_sum+ power_now;
                    current_sum = current_sum+ current_now ;
                    voltage_sum = voltage_sum+ voltage;
                    counter_for_power++;
                    if (DBG)
                        Log.d(TAG, "Power avereage: " + power_sum / counter_for_power);
                   // power_avg = power_sum / counter_for_power;
                   // current_avg = current_sum /counter_for_power;
                   // voltage_avg = voltage_sum /counter_for_power;


                } catch (Exception e) {
                    Log.d(TAG, "Voltage Error: " + e);
                }


                powerHandler.postDelayed(powerRefresh, cpu_conf_time_interval * 5); // in every 0.5 sec

            } catch (Exception e) {
                Log.i(TAG, "Error occured " + e);
                powerHandler.postDelayed(powerRefresh, cpu_conf_time_interval * 5); // in every 0.5 sec
            }
        }
    };



    private PendingIntent getActivityDetectionPendingIntent() {

        Intent intent = new Intent(getApplicationContext(), DetectedActivitiesIntentService.class);

        // We use FLAG_UPDATE_CURRENT so that we get the same pending intent back when calling
        // requestActivityUpdates() and removeActivityUpdates().
        return PendingIntent.getService(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }




    private void startSensorListeners() {
        try {
            Log.d(TAG, "startSensorListeners");

            mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
            mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_NORMAL);


            Log.d(TAG, "Sensor started: " + mSensorManager);

        } catch (Exception e) {
            if (DBG) Log.d(TAG, "ERROR in sensor registering: " + e);
        }
    }

    private void stopSensorListeners() {
        try{
            Log.d(TAG, "stopSensorListeners");
            mSensorManager.unregisterListener(ServiceClassPhone.this);
            Log.d(TAG, "Sensor stoppped: " + mSensorManager);
//        wakeLock.release();

        } catch (Exception e) {
            if (DBG) Log.d(TAG, "ERROR in sensor unregistering: " + e);
        }
    }



    @Override
    // in each sensor changes this override function keeps the everything avout the sensor. And we get 2 of these info
    public void onSensorChanged(SensorEvent event) {
        String key = event.sensor.getName();
        double values = event.values[0];
        Sensor sensor = event.sensor;

        try {
            if (sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                accellerometerEvent++;                  // this is event counts when sensor changes, this counts all the events changings. It shouldnt be necessary though
                accellerometerSensor = values + " " + event.values[1] + " " + event.values[2] + " " + accellerometerEvent; // This is the string for value and seen event count.
                //   accel_x=accel_x+values;
                //   accel_y=accel_y+event.values[1];
                //   accel_z=accel_z+event.values[2];
                accell_phone_x = values;
                accell_phone_y = event.values[1];
                accell_phone_z = event.values[2];
                //if (DBG) Log.d(TAG , "Sensors accel: " + accell_phone_x+" " +accell_phone_y);
            }
            if (sensor.getType() == Sensor.TYPE_GYROSCOPE) {
                gyroscopeEvent++;                  // this is event counts when sensor changes, this counts all the events changings. It shouldnt be necessary though
                gyroscopeSensor = values + " " + event.values[1] + " " + event.values[2] + " " + gyroscopeEvent; // This is the string for value and seen event count.
                //   accel_x=accel_x+values;
                //   accel_y=accel_y+event.values[1];
                //   accel_z=accel_z+event.values[2];
                gyro_phone_x = values;
                gyro_phone_y = event.values[1];
                gyro_phone_z = event.values[2];
                //if (DBG) Log.d(TAG , "Sensors accel: " + accell_phone_x+" " +accell_phone_y);
            }
            if (sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE) {
                gyroscopeEvent++;                  // this is event counts when sensor changes, this counts all the events changings. It shouldnt be necessary though
                gyroscopeSensor = values + " " + event.values[1] + " " + event.values[2] + " " + gyroscopeEvent; // This is the string for value and seen event count.
                //   accel_x=accel_x+values;
                //   accel_y=accel_y+event.values[1];
                //   accel_z=accel_z+event.values[2];
                gyro_phone_x = values;
                gyro_phone_y = event.values[1];
                gyro_phone_z = event.values[2];
                //if (DBG) Log.d(TAG , "Sensors accel: " + accell_phone_x+" " +accell_phone_y);
            }



        } catch (Exception e) {
            Log.d(TAG , "Error in sensor reading");
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "onConnectionFailed: " + i);
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        if (Log.isLoggable(TAG, Log.DEBUG)) {
            Log.d(TAG, "onConnectionFailed: " + connectionResult);
        }
    }


    public class LocalBinder extends Binder {
        ServiceClassPhone getService() {
            // Return this instance of LocalService so clients can call public methods
            return ServiceClassPhone.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }



}

